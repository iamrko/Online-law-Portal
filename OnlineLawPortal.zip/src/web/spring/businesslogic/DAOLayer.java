package web.spring.businesslogic;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class DAOLayer {

	private JdbcTemplate jt;

	@Autowired
	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
		System.out.println("DAO");
	}

	public boolean getregister(User usr) {
		
		boolean status = false;
		System.out.println(usr.fname);
		String sql = "call insertProcedure(?,?,?,?,?)";
		int row = jt.update(sql,usr.fname,usr.lname,usr.email,usr.pass,usr.gender);
		if(row==1){
			status = true;
			System.out.println("true");
		}
		return status;
	}

	public String getlogin(String email, String pass) {
		
		String sql = "select email from user where pass=? and email=?";
		Object obj[] = {pass,email};
		RowMapper<String> rm = new RowMapper<String>() {
			
			@Override
			public String mapRow(ResultSet arg0, int arg1) throws SQLException {
				String name = arg0.getString("email");
				return name;
			}
		};
		List<String> list = jt.query(sql,obj,rm);
		System.out.println(list.size());
		if(list.size()>0)
			return list.get(0);
		else
			return null;
	}

	public boolean getform(Eform eform) {
		
		String sql = "insert into eform(court,casetype,fname,lname,address,contact,email,petitionertype,incidentdate,relationship,respfname,resplname,respaddress,respcontact)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		int row = jt.update(sql,eform.court,eform.casetype,eform.fname,eform.lname,eform.address,eform.contact,eform.email,eform.petitionertype
				,eform.date,eform.relationship,eform.respfname,eform.resplname,eform.respaddr,eform.respcontact);
		if(row>0)
			return true;
		else
			return false;
	}

	public List<Laws> getlaws() {
		String sql = "select section,offence,bail,punishment from laws";
		RowMapper<Laws> rm = new RowMapper<Laws>() {
			
			@Override
			public Laws mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Laws(arg0.getString("section"),arg0.getString("offence"),arg0.getString("bail"),arg0.getString("punishment"));
			}
		};
		List<Laws> list = jt.query(sql, rm);
		return list;
	}

	public Case getcase(int caseno) {
		
		String sql = "select courtName,caseStatus,judgement from casedetails where caseNo=?";
		Object obj[]={caseno};
		RowMapper<Case> rm = new RowMapper<Case>() {
			
			@Override
			public Case mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Case(caseno,arg0.getString("courtName"),arg0.getString("caseStatus"),arg0.getString("judgement"));
			}
		};
		List<Case> list = jt.query(sql,obj,rm);
		return list.get(0);
	}

	public boolean getcomment(String panel, int caseno) {
		String sql = "update casedetails set comment=? where caseNo=?";
		int row = jt.update(sql,panel,caseno);
		if(row>0)
			return true;
		return false;
	}

	public Laws getlawbyid(int secid) {
		String sql = "select section,offence,bail,punishment from laws where secid=?";
		Object obj[]={secid};
		RowMapper<Laws> rm = new RowMapper<Laws>() {
			
			@Override
			public Laws mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Laws(secid,arg0.getString("section"),arg0.getString("offence"),arg0.getString("bail"),arg0.getString("punishment"));
			}
		};
		List<Laws> list = jt.query(sql, obj, rm);
		return list.get(0);
	}

	public boolean updatelaw(Laws laws) {
		String sql = "update laws set section=?,offence=?,bail=?,punishment=? where secid=?";
		Object obj[]={laws.section,laws.offence,laws.bail,laws.punishment,laws.secid};
		int row = jt.update(sql,obj);
		if(row>0)
			return true;
		return false;
	}

	public boolean deletelaw(int secid) {
		String sql = "delete from laws where secid=?";
		int row = jt.update(sql,secid);
		if(row>0)
			return true;
		return false;
	}

	public boolean addlaw(Laws laws) {
		String sql = "insert into laws(section,offence,bail,punishment)values(?,?,?,?)";
		int row = jt.update(sql,laws.section,laws.offence,laws.bail,laws.punishment);
		if(row>0)
			return true;
		return false;
	}
	
	public boolean addLawyerDetails(String lawyerName, String qualification, String expert, String emailId,
			String lawyerAddress, String city, long contactNo) {
		
		String sql="insert into lawyer(lawyerName,qualification,expert,emailId,lawyerAddress,city,contact) values(?,?,?,?,?,?,?)";
		int row=jt.update(sql,lawyerName ,qualification ,expert ,emailId ,lawyerAddress ,city ,contactNo);
		if(row>0)		
			return true;
		else
			return false;
	}

	public List<Lawyer> getAllLawyers() {
		
		String sql="select * from lawyer";
		List<Lawyer> list=null;
		
		RowMapper<Lawyer> rm = new RowMapper<Lawyer>() {
			
			@Override
			public Lawyer mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Lawyer(arg0.getInt("srNo"),arg0.getString("lawyerName"),arg0.getString("qualification"),arg0.getString("expert"), arg0.getString("emailid"), arg0.getString("lawyerAddress"), arg0.getString("city"), arg0.getLong("contact"));
			}
		};
		list=jt.query(sql, rm);
		return list;
	}
	
	public List<Lawyer> getAllLawyersForUser() {
		// TODO Auto-generated method stub
		String sql="select * from lawyer";
		List<Lawyer> list=null;
		
		RowMapper<Lawyer> rm = new RowMapper<Lawyer>() {
			
			@Override
			public Lawyer mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Lawyer(arg0.getInt("srNo"),arg0.getString("lawyerName"),arg0.getString("qualification"),arg0.getString("expert"), arg0.getString("emailid"), arg0.getString("lawyerAddress"), arg0.getString("city"), arg0.getLong("contact"));
			}
		};
		list=jt.query(sql, rm);
		return list;
	}

	public Lawyer getLawyerById(int id) {
		
		String sql = "select lawyerName,qualification,expert,emailId,lawyerAddress,city,contact from lawyer where srNo=?";
		Object obj[]={id};
		RowMapper<Lawyer> rm = new RowMapper<Lawyer>() {
			
			@Override
			public Lawyer mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Lawyer(id, arg0.getString("lawyerName"),arg0.getString("qualification"),arg0.getString("expert"),arg0.getString("emailId"), arg0.getString("lawyerAddress"), arg0.getString("city"), arg0.getLong("contact"));
			}
		};
		List<Lawyer> list = jt.query(sql,obj,rm);
		return list.get(0);
	}

	public boolean updatelawyer(Lawyer lawyer) {
		String sql = "update lawyer set lawyerName=?,qualification=?,expert=?,emailid=?,lawyerAddress=?,city=?,contact=? where srNo=?";
		int row = jt.update(sql,lawyer.getLawyerName(),lawyer.getQualification(),lawyer.getExpert(),lawyer.getEmailId(),lawyer.getAddress(),lawyer.getCity(),lawyer.getContact(),lawyer.getSrNo());
		if(row>0)
			return true;
		return false;
	}

	public boolean deletelawyer(int id) {
		String sql="delete from lawyer where srNo=?";
		int row = jt.update(sql,id);
		if(row>0)
			return true;
		return false;
	}
	
	public List<Laws> getLaws() {
		// TODO Auto-generated method stub
		String stmt="select section,offence,bail,punishment from laws";
		List<Laws> list=null;
		RowMapper<Laws> rm = new RowMapper<Laws>() {
			
			@Override
			public Laws mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Laws(arg0.getString("section"),arg0.getString("offence"),arg0.getString("bail"), arg0.getString("punishment"));
			}
		};
		list=jt.query(stmt, rm);
		System.out.println(list);
		return list;
	}
	public List<Case> getallcase() {
		String sql="select caseNo,courtName,caseStatus,judgement,comment from casedetails where caseNo is not null";
		RowMapper<Case> rm = new RowMapper<Case>() {
			
			@Override
			public Case mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Case(arg0.getInt("caseNo"),arg0.getString("courtName"),arg0.getString("caseStatus"),arg0.getString("judgement"),arg0.getString("comment"));
			}
		};
		List<Case> list = jt.query(sql,rm);
		return list;
	}

	public Case getCaseById(int id) {
		String sql="select courtName,caseStatus,judgement,comment from casedetails where caseNo=?";
		Object obj[]={id};
		RowMapper<Case> rm = new RowMapper<Case>() {
			
			@Override
			public Case mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Case(id,arg0.getString("courtName"),arg0.getString("caseStatus"),arg0.getString("judgement"));
			}
		};
		List<Case> list = jt.query(sql,obj,rm);
		return list.get(0);
	}

	public boolean updatecase(Case case1) {
		String sql = "update casedetails set courtName=?,caseStatus=?,judgement=? where caseNo=?";
		Object obj[]={case1.courtName,case1.caseStatus,case1.judgement,case1.caseNo};
		int row = jt.update(sql,obj);
		if(row>0)
			return true;
		return false;
	}

	public boolean deletecase(int id) {
		String sql = "delete from casedetails where caseNo=?";
		int row = jt.update(sql,id);
		if(row>0)
			return true;
		return false;
	}

	public boolean addcase(Case case1) {
		String sql = "insert into casedetails(caseNo,courtName,caseStatus,judgement)values(?,?,?,?)";
		int row = jt.update(sql,case1.caseNo,case1.courtName,case1.caseStatus,case1.judgement);
		if(row>0)
			return true;
		return false;
	}
	
	public String loginAdmin(String username, String password) {
		// TODO Auto-generated method stub
		String stmt="select username from admin where username=? AND password=?";
		Object obj[]= {username, password};
		RowMapper<String> rm = new RowMapper<String>() {
			
			@Override
			public String mapRow(ResultSet arg0, int arg1) throws SQLException {
				String uname = arg0.getString("username");
				return uname;
			}
		};
		List<String> list=jt.query(stmt, obj, rm);
		return list.get(0);
	}

	public String loginPanel(String username, String password) {
		String stmt="select username from panel where username=? AND password=?";
		Object obj[]= {username, password};
		RowMapper<String> rm = new RowMapper<String>() {
			
			@Override
			public String mapRow(ResultSet arg0, int arg1) throws SQLException {
				String pname = arg0.getString("username");
				return pname;
			}
		};
		List<String> list=jt.query(stmt, obj, rm);
		return list.get(0);
	}

	public List<Case> gethearing(String uname) {
		String sql="select caseNo,courtName,caseStatus,judgement,comment from casedetails where username=?";
		Object obj[]= {uname};
		RowMapper<Case> rm = new RowMapper<Case>() {
			
			@Override
			public Case mapRow(ResultSet arg0, int arg1) throws SQLException {
				return new Case(arg0.getInt("caseNo"),arg0.getString("courtName"),arg0.getString("caseStatus"),arg0.getString("judgement"),arg0.getString("comment"));
			}
		};
		List<Case> list = jt.query(sql,obj,rm);
		return list;
	}

}
