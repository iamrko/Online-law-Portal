package web.spring.businesslogic;

public class Laws {

	public String section,offence,bail,punishment;
	public int secid;

	public Laws(int secid,String section, String offence, String bail, String punishment) {
		//super();
		this.secid = secid;
		this.section = section;
		this.offence = offence;
		this.bail = bail;
		this.punishment = punishment;
	}

	public Laws(String section, String offence, String bail, String punishment) {
		this.section = section;
		this.offence = offence;
		this.bail = bail;
		this.punishment = punishment;
	}
	
	public int getSecid() {
		return secid;
	}

	public void setSecid(int secid) {
		this.secid = secid;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getOffence() {
		return offence;
	}

	public void setOffence(String offence) {
		this.offence = offence;
	}

	public String getBail() {
		return bail;
	}

	public void setBail(String bail) {
		this.bail = bail;
	}

	public String getPunishment() {
		return punishment;
	}

	public void setPunishment(String punishment) {
		this.punishment = punishment;
	}
}
