package web.spring.businesslogic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceLayer {

private DAOLayer dl;
	
	@Autowired
	public void setDl(DAOLayer dl) {
		this.dl = dl;
		System.out.println("service");
	}

	public boolean getregister(User usr) {
		
		return dl.getregister(usr);
	}

	public String getlogin(String email, String pass) {
		
		return dl.getlogin(email,pass);
	}

	public boolean getform(Eform eform) {
		return dl.getform(eform);
	}

	public List<Laws> getlaws() {
		return dl.getlaws();
	}

	public Case getcase(int caseno) {
		return dl.getcase(caseno);
	}

	public boolean getcomment(String panel, int caseno) {
		return dl.getcomment(panel,caseno);
	}

	public Laws getlawbyid(int secid) {
		return dl.getlawbyid(secid);
	}

	public boolean updatelaw(Laws laws) {
		return dl.updatelaw(laws);
	}

	public boolean deletelaw(int secid) {
		return dl.deletelaw(secid);
	}

	public boolean addlaw(Laws laws) {
		return dl.addlaw(laws);
	}
	
	public boolean addLawyerDetails(String lawyerName, String qualification, String expert, String emailId,
			String lawyerAddress, String city, long contactNo) {
		return dl.addLawyerDetails(lawyerName ,qualification ,expert ,emailId ,lawyerAddress ,city , contactNo );
	}

	public List<Lawyer> getAllLawyers() {
		return dl.getAllLawyers();
	}
	
	public List<Lawyer> getAllLawyersForUser() {
		// TODO Auto-generated method stub
		return dl.getAllLawyersForUser();
	}
	
	public Lawyer getLawyerById(int id) {
		return dl.getLawyerById(id);
	}

	public boolean updatelawyer(Lawyer lawyer) {
		return dl.updatelawyer(lawyer);
	}

	public boolean deletelawyer(int id) {
		return dl.deletelawyer(id);
	}
	
	public List<Laws> getLaws() {
		// TODO Auto-generated method stub
		return dl.getLaws();
	}

	public boolean deletecase(int id) {
		return dl.deletecase(id);
	}

	public boolean updatecase(Case case1) {
		// TODO Auto-generated method stub
		return dl.updatecase(case1);
	}

	public Case getCaseById(int id) {
		// TODO Auto-generated method stub
		return dl.getCaseById(id);
	}

	public List<Case> getallcase() {
		// TODO Auto-generated method stub
		return dl.getallcase();
	}

	public boolean addcase(Case case1) {
		// TODO Auto-generated method stub
		return dl.addcase(case1);
	}
	
	public String loginAdmin(String username, String password) {
		// TODO Auto-generated method stub
		return dl.loginAdmin(username,password);
	}

	public String loginPanel(String username, String password) {
		// TODO Auto-generated method stub
		return dl.loginPanel(username,password);
	}

	public List<Case> gethearing(String uname) {
		// TODO Auto-generated method stub
		return dl.gethearing(uname);
	}

}
