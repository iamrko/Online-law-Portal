package web.spring.businesslogic;

public class Case {

	public String courtName,caseStatus,judgement,comment;
	public int caseNo;
	
	public Case(){}
	public String getCourtName() {
		return courtName;
	}
	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}
	public String getJudgement() {
		return judgement;
	}
	public void setJudgement(String judgement) {
		this.judgement = judgement;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(int caseNo) {
		this.caseNo = caseNo;
	}
	public Case(int caseNo,String courtName, String caseStatus, String judgement) {
		//super();
		this.courtName = courtName;
		this.caseStatus = caseStatus;
		this.judgement = judgement;
		//this.comment = comment;
		this.caseNo = caseNo;
	}
	
	public Case(int caseNo,String courtName, String caseStatus, String judgement,String comment) {
		//super();
		this.courtName = courtName;
		this.caseStatus = caseStatus;
		this.judgement = judgement;
		this.comment = comment;
		this.caseNo = caseNo;
	}
}
