package web.spring.businesslogic;

public class Lawyer {

	private String lawyerName;
	private String qualification;
	private String expert;
	private String emailId;
	private String address;
	private String city;
	private long contact;
	private int srNo;
	public int getSrNo() {
		return srNo;
	}
	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}
	public String getLawyerName() {
		return lawyerName;
	}
	public void setLawyerName(String lawyerName) {
		this.lawyerName = lawyerName;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getExpert() {
		return expert;
	}
	public void setExpert(String expert) {
		this.expert = expert;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public Lawyer(int srNo,String lawyerName, String qualification, String expert, String emailId, String address, String city,
			long contact) {
		//super();
		this.srNo = srNo;
		this.lawyerName = lawyerName;
		this.qualification = qualification;
		this.expert = expert;
		this.emailId = emailId;
		this.address = address;
		this.city = city;
		this.contact = contact;
	}
	
}
