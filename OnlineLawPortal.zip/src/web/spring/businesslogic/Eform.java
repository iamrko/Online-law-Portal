package web.spring.businesslogic;

import java.sql.Date;

public class Eform {

	String court,casetype,fname,lname,address, email,petitionertype,relationship,respfname,resplname,respaddr;
	Date date;
	long respcontact,contact;
	
	public Eform(){}
	public Eform(String court, String casetype, String fname, String lname, String address, String email,
			String petitionertype, String relationship, String respfname, String resplname, String respaddr, Date date,
			long respcontact, long contact) {
		//super();
		this.court = court;
		this.casetype = casetype;
		this.fname = fname;
		this.lname = lname;
		this.address = address;
		this.email = email;
		this.petitionertype = petitionertype;
		this.relationship = relationship;
		this.respfname = respfname;
		this.resplname = resplname;
		this.respaddr = respaddr;
		this.date = date;
		this.respcontact = respcontact;
		this.contact = contact;
	}
	public String getCourt() {
		return court;
	}
	public void setCourt(String court) {
		this.court = court;
	}
	public String getCasetype() {
		return casetype;
	}
	public void setCasetype(String casetype) {
		this.casetype = casetype;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPetitionertype() {
		return petitionertype;
	}
	public void setPetitionertype(String petitionertype) {
		this.petitionertype = petitionertype;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getRespfname() {
		return respfname;
	}
	public void setRespfname(String respfname) {
		this.respfname = respfname;
	}
	public String getResplname() {
		return resplname;
	}
	public void setResplname(String resplname) {
		this.resplname = resplname;
	}
	public String getRespaddr() {
		return respaddr;
	}
	public void setRespaddr(String respaddr) {
		this.respaddr = respaddr;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public long getRespcontact() {
		return respcontact;
	}
	public void setRespcontact(long respcontact) {
		this.respcontact = respcontact;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	
}
