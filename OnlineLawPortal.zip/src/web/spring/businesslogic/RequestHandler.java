package web.spring.businesslogic;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class RequestHandler {

	private ServiceLayer sr;
	
	@Autowired
	public void setSr(ServiceLayer sr) {
		this.sr = sr;
		System.out.println("request");
	}

	@RequestMapping("/getregister")
	public ModelAndView getregister(@RequestParam("fname") String fname,@RequestParam("lname") String lname,@RequestParam("email") String email,@RequestParam("pass") String pass,@RequestParam("gender") String gender){
		
		ModelAndView mv = new ModelAndView();
		boolean status = sr.getregister(new User(fname,lname,email,pass,gender));
		if(status){
			mv.setViewName("/HomePage.jsp");
		}
		return mv;
	}
	
	@RequestMapping("/login")
	public ModelAndView getlogin(HttpServletRequest request)
	{
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		String name = sr.getlogin(email,pass);
		ModelAndView mv = new ModelAndView();
		if(name!=null){
			HttpSession session = request.getSession();
			session.setAttribute("name", name);
			mv.setViewName("/WEB-INF/afterLogin.jsp");
		}
		else{
			mv.setViewName("/HomePage.jsp");
			mv.addObject("k1","Login Failed");}
		return mv;
	}
	
	@RequestMapping("/impHearing")
	public ModelAndView gethearing(HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
		String uname = (String)session.getAttribute("name");
		System.out.println(uname);
		ModelAndView mv = new ModelAndView();
		if(session.getAttribute("name")!=null) {
			 List<Case> list= sr.gethearing(uname);
			if(list.size()>0) {
				
				mv.addObject("k1",list);
				System.out.println(list);
			}
			else {
				mv.addObject("k2","No Case found registered by you!");
			}
			mv.setViewName("/impHearing.jsp");
		}
		else {
			mv.setViewName("/HomePage.jsp");
			mv.addObject("k2","Login First!!");
		}
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		if(session!=null)
		{
			session.removeAttribute("name");
			session.invalidate();
		}
		return new ModelAndView("/HomePage.jsp");
	}
	
	@RequestMapping("/getform")
	public ModelAndView getform(HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
		ModelAndView mv = new ModelAndView();
		if(session.getAttribute("name")!=null) {
		long contact = Long.parseLong(request.getParameter("contactno"));
		Date incidentdate = Date.valueOf(request.getParameter("incidentdate"));
		long respcontact = Long.parseLong(request.getParameter("respcontact"));
		Eform form = new Eform(request.getParameter("court"),request.getParameter("casetype"),request.getParameter("firstname"),request.getParameter("lastname"),request.getParameter("address")
				,request.getParameter("email"),request.getParameter("petitionertype"),request.getParameter("relationship"),request.getParameter("respfname"),request.getParameter("resplname"),request.getParameter("respaddress"),incidentdate,contact,respcontact);
boolean status = sr.getform(form);
		if(status) {
			mv.addObject("k1",form);
			mv.setViewName("/WEB-INF/confirmEform.jsp");
		}	
		else {
			mv.addObject("k1","Registration failed");
		mv.setViewName("/eForm.jsp");
		}
		}
		
		else {
			mv.setViewName("/HomePage.jsp");
			mv.addObject("k2","Login first!!");
		}
		return mv;
	}
	
	@RequestMapping("/getlaws")
	public ModelAndView getlaws(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		List<Laws> list = sr.getlaws();
		HttpSession session = request.getSession();
		if(session.getAttribute("uname")!=null){
		if(list.size()>0)
			mv.addObject("k1",list);
		else
			mv.addObject("k1","Law doesn't found");
		mv.setViewName("/WEB-INF/adminlaws.jsp");
		}
		else{
			mv.addObject("k2","Login First!!");
			mv.setViewName("/AdminLoginPage.jsp");
		}
		return mv;
	}
	
	@RequestMapping("/addcase")
	public ModelAndView addcase(@RequestParam("adcaseNo") int caseNo,@RequestParam("adcourtName") String courtName,@RequestParam("adcaseStatus") String caseStatus,@RequestParam("adjudgement") String judgement){
		ModelAndView mv = new ModelAndView();
		boolean status = sr.addcase(new Case(caseNo, courtName, caseStatus, judgement));
		if(!status)
			mv.addObject("k5","Insertion failed");
		mv.setViewName("/WEB-INF/admincase.jsp");
		return mv;
	}
	
	@RequestMapping("/getallcase")
	public ModelAndView getallcase(HttpServletRequest request){
		List<Case> list = sr.getallcase();
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		if(session.getAttribute("uname")!=null){
		if(list.size()>0)
			mv.addObject("k1",list);
		mv.setViewName("/WEB-INF/admincase.jsp");
		}
		else{
			mv.addObject("key1","Invalid username or password....");
			mv.setViewName("/AdminLoginPage.jsp");
		}
		return mv;
	}
	
	@RequestMapping("/getstatus")
	public ModelAndView getstatus(@RequestParam("caseno") int caseno,HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
		ModelAndView mv = new ModelAndView();
		if(session.getAttribute("name")!=null) {
		Case ca = sr.getcase(caseno);
		if(ca!=null)
			mv.addObject("k1",ca);
		else
			mv.addObject("k1","Case not found");
		mv.setViewName("/impHearing.jsp");
		}
		else {
			mv.setViewName("/HomePage.jsp");
			mv.addObject("k2","Login first!!");
		}
		return mv;
	}
	
	@RequestMapping("/getcase")
	public ModelAndView getcase(@RequestParam("caseno") int caseno,HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		if(session.getAttribute("pname")!=null){
		Case ca = sr.getcase(caseno);
		if(ca!=null)
			mv.addObject("k1",ca);
		else
			mv.addObject("k1","Case not found");
		mv.setViewName("/WEB-INF/Panel.jsp");
		}
		else{
			mv.addObject("k3","Login First!!");
			mv.setViewName("/AdminLoginPage.jsp");
		}
		return mv;
	}
	
	@RequestMapping("editcase/{id}")
	public ModelAndView getCaseById(@PathVariable int id){
		ModelAndView mv = new ModelAndView();
		Case cs = sr.getCaseById(id);
		if(cs!=null)
			mv.addObject("k2",cs);
		mv.setViewName("/WEB-INF/admincase.jsp");
		return mv;
	}
	
	@RequestMapping("/updatecase")
	public ModelAndView updatecase(@RequestParam("caseNo") int caseNo,@RequestParam("courtName") String courtName,@RequestParam("caseStatus") String caseStatus,@RequestParam("judgement") String judgement){
		ModelAndView mv = new ModelAndView();
		boolean status = sr.updatecase(new Case(caseNo, courtName, caseStatus, judgement));
		if(!status)
			mv.addObject("k3","updation failed");
		mv.setViewName("/WEB-INF/admincase.jsp");
		return mv;
	}
	@RequestMapping("/deletecase/{id}")
	public ModelAndView deletecase(@PathVariable int id){
		ModelAndView mv = new ModelAndView();
		boolean status = sr.deletecase(id);
		if(!status)
			mv.addObject("k4","deletion failed");
		mv.setViewName("/WEB-INF/admincase.jsp");
		return mv;
	}

	
	@RequestMapping("/getcomment")
	public ModelAndView getcomment(@RequestParam("panel") String panel,@RequestParam("caseno") int caseno)
	{
		ModelAndView mv = new ModelAndView();
		boolean status = sr.getcomment(panel,caseno);
		if(status)
			mv.addObject("k2","Comment Updated Successfully!");
		else
			mv.addObject("k2","Updation failed!");
		mv.setViewName("WEB-INF/Panel.jsp");
		return mv;
	}
	
	@RequestMapping("/addlaw")
	public ModelAndView addlaw(@RequestParam("adsection") String section,@RequestParam("adoffence") String offence,@RequestParam("adbail") String bail,@RequestParam("adpunishment") String punishment){
		
		boolean status = sr.addlaw(new Laws(section,offence,bail,punishment));
		ModelAndView mv = new ModelAndView();
		if(!status)
			mv.addObject("k4","Insertion Failed");
		mv.setViewName("/WEB-INF/adminlaws.jsp");
		return mv;
	}
	@RequestMapping("/editlaw/{secid}")
		public ModelAndView getlawbyid(@PathVariable int secid){
			ModelAndView mv = new ModelAndView();
			Laws law= sr.getlawbyid(secid);
			mv.addObject("k2",law);
			mv.setViewName("/WEB-INF/adminlaws.jsp");
			return mv;
	}
	
	@RequestMapping("/updatelaw")
	public ModelAndView updatelaw(@RequestParam("secid") int secid,@RequestParam("section") String section,@RequestParam("offence") String offence,@RequestParam("bail") String bail,@RequestParam("punishment") String punishment)
	{
		sr.updatelaw(new Laws(secid,section,offence,bail,punishment));
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/WEB-INF/adminlaws.jsp");
		return mv;
	}
	
	@RequestMapping("/deletelaw/{secid}")
	public ModelAndView deletelaw(@PathVariable int secid){
		ModelAndView mv = new ModelAndView();
		boolean status = sr.deletelaw(secid);
		if(!status)
			mv.addObject("k3","deletion failed");
		mv.setViewName("/WEB-INF/adminlaws.jsp");
		return mv;
	}
	
	@RequestMapping("/addLawyer")
	public ModelAndView addLawyer(@RequestParam("adlawyername") String lawyerName, @RequestParam("adqualification") String qualification, @RequestParam("adexpert") String expert, @RequestParam("ademailid") String emailId, @RequestParam("adaddress") String lawyerAddress, @RequestParam("adcity") String city, @RequestParam("adcontact") long contactNo) {
		
		ModelAndView mv=new ModelAndView();
		boolean status=sr.addLawyerDetails(lawyerName ,qualification ,expert ,emailId ,lawyerAddress ,city ,contactNo);
		if(status) {
			mv.addObject("k3","Lawyer details added to the database successfully....");
		}
		else {
			mv.addObject("k3","Adding Lawyer details failed....!");
		}
		mv.setViewName("/WEB-INF/adminlawyer.jsp");
		return mv;
	}
	
	@RequestMapping("/getlawyer")
	public ModelAndView getlawyer(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView mv=new ModelAndView();
		if(session.getAttribute("name")!=null) {
		List<Lawyer> list=sr.getAllLawyers();
		
		if(list.size()>0) {
			mv.addObject("k1",list);
		}
		else {
			mv.addObject("k1","Something's wrong....");
		}
		mv.setViewName("/WEB-INF/lawyer.jsp");
		}
		else {
			mv.setViewName("/HomePage.jsp");
			mv.addObject("k2","Login First!!");
		}
		return mv;
	}
	
	@RequestMapping("/getlawyerforuser")
	public ModelAndView getLawyerForUser(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView mv=new ModelAndView();
		if(session.getAttribute("name")!=null) {
		List<Lawyer> list=sr.getAllLawyersForUser();
		
		if(list.size()>0) {
			mv.addObject("k1",list);
		}
		else {
			mv.addObject("k1","Something's wrong....");
		}
		mv.setViewName("/WEB-INF/lawyersForUser.jsp");
		}
		else {
			mv.setViewName("/HomePage.jsp");
			mv.addObject("k2","Login First!!");
		}
		return mv;
	}
	@RequestMapping("/viewLawyers")
	public ModelAndView getLawyers(HttpServletRequest request) {
		
		ModelAndView mv=new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("uname")!=null){
			List<Lawyer> list=sr.getAllLawyers();
		if(list.size()>0)
			mv.addObject("k1",list);
		else 
			mv.addObject("k1","Something's wrong....");
		mv.setViewName("/WEB-INF/adminlawyer.jsp");
		}
		else{
			mv.addObject("k2","Login First!!");
			mv.setViewName("/AdminLoginPage.jsp");
		}
		return mv;
	}
	
	@RequestMapping("/editlawyer/{id}")
	public ModelAndView getLawyerById(@PathVariable int id){
		ModelAndView mv = new ModelAndView();
		Lawyer lawyer = sr.getLawyerById(id);
		if(lawyer!=null)
			mv.addObject("k2",lawyer);
		else
			mv.addObject("k2","lawyer not found");
		mv.setViewName("/WEB-INF/adminlawyer.jsp");
		return mv;
	}
	
	@RequestMapping("/updatelawyer")
	public ModelAndView updatelawyer(@RequestParam("srNo") int srNo,@RequestParam("lawyername") String lawyerName,@RequestParam("qualification") String qualification,@RequestParam("expert") String expert,@RequestParam("emailid") String emailId,@RequestParam("address") String address,@RequestParam("city") String city,@RequestParam("contact") long contact){
		ModelAndView mv = new ModelAndView();
		boolean status = sr.updatelawyer(new Lawyer(srNo, lawyerName, qualification, expert, emailId, address, city, contact));
		if(!status)
			mv.addObject("k3","Updation Failed");
		mv.setViewName("/WEB-INF/adminlawyer.jsp");
		return mv;
	}
	
	@RequestMapping("/deletelawyer/{id}")
	public ModelAndView deletelawyer(@PathVariable int id){
		//ModelAndView mv = new ModelAndView();
		boolean status = sr.deletelawyer(id);
		/*if(!status)
			mv.addObject("k3","Deletion Failed");
		mv.setViewName("/WEB-INF/adminlawyer.jsp");
		return mv;*/
		return new ModelAndView("/WEB-INF/adminlawyer.jsp");
	}
	
	@RequestMapping("/getLaws")
	public ModelAndView getLaws() {
		ModelAndView mv=new ModelAndView();
		List<Laws> list=sr.getLaws();
		if(list.size()>0)
			mv.addObject("key1", list);
		mv.setViewName("/WEB-INF/PublicLawRequest.jsp");
		return mv;
	}
	
	@RequestMapping("/adminLogin")
	public ModelAndView loginAdmin(@RequestParam("adminUsername") String username, @RequestParam("adminPassword") String password,HttpServletRequest request) {
		
		ModelAndView mv=new ModelAndView();
		String uname=sr.loginAdmin(username,password);
		if(uname!=null) {
			HttpSession session = request.getSession();
			session.setAttribute("uname", uname);
			mv.setViewName("/admin.jsp");
		}
		else {
			mv.addObject("key1","Invalid username or password....");
			mv.setViewName("/AdminLoginPage.jsp");
		}
		return mv;	
	}
	
	@RequestMapping("/adminlogout")
	public ModelAndView adminlogout(HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		if(session!=null)
		{
			session.removeAttribute("uname");
			session.invalidate();
		}
		mv.setViewName("/AdminLoginPage.jsp");
		return mv;
	}
	@RequestMapping("/panelLogin")
	public ModelAndView loginPanel(@RequestParam("panelUsername") String username,@RequestParam("panelPassword") String password,HttpServletRequest request) {
		
		ModelAndView mv=new ModelAndView();
		String pname=sr.loginPanel(username,password);
		if(pname!=null) {
			HttpSession session = request.getSession(); 
			session.setAttribute("pname", pname);
			mv.setViewName("/WEB-INF/Panel.jsp");
		}
		else {
			mv.addObject("key2","Something's wrong");
			mv.setViewName("/AdminLoginPage.jsp");
		}
		return mv;	
	}
	
	@RequestMapping("/penallogout")
	public ModelAndView penallogout(HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		if(session!=null)
		{
			session.removeAttribute("pname");
			session.invalidate();
		}
		mv.setViewName("/AdminLoginPage.jsp");
		return mv;
	}
	@RequestMapping("/getallpanelcase")
	public ModelAndView getallpanelcase(HttpServletRequest request)
	{
		
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		if(session.getAttribute("pname")!=null){
			List<Case> list = sr.getallcase();
			if(list.size()>0)
				mv.addObject("k3",list);
		mv.setViewName("WEB-INF/Panel.jsp");
		}
		else{
			mv.setViewName("/AdminLoginPage.jsp");
			mv.addObject("k3","Login First!!");
		}
		return mv;
	}
}
